本资源包为多位玩家共同开发的成果。
游戏版本、资源包名称以及开发者如下
1.12	红石发光材质	xwjcool
1.12	Origami发光材质	喵芋折纸
1.14	Origami发光材质	吾名加大
1.16-1.17	Origami高光材质	AGANG
1.18	Silvery发光材质	AGANG
Silvery材质未来将会随MC版本继续更新。
AGANG网址：www.agang.org